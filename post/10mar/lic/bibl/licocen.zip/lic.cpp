/*
  Przykladowe rozwiazanie zadania Licytacja (niezbyt madre)
*/
#include "cliclib.h"

int n;

int stos, stawka;

int main() {
  n = inicjuj();
  while (true) {
    alojzy(1); // Alojzy zawsze pasuje
    int x = bajtazar(); // Wczytujemy ruch Bajtazara, ale go ignorujemy
  }
  return 0;
}
